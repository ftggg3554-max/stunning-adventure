package com.stark.specfix;

import com.github.retrooper.packetevents.PacketEvents;
import com.github.retrooper.packetevents.event.PacketListenerAbstract;
import com.github.retrooper.packetevents.event.PacketListenerPriority;
import com.github.retrooper.packetevents.event.PacketSendEvent;
import com.github.retrooper.packetevents.protocol.packettype.PacketType;
import com.github.retrooper.packetevents.util.Vector3d;
import com.github.retrooper.packetevents.wrapper.play.server.WrapperPlayServerExplosion;
import io.papermc.paper.event.player.PlayerInventorySlotChangeEvent;
import org.bukkit.Bukkit;
import org.bukkit.NamespacedKey;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerChangedWorldEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerVelocityEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.persistence.PersistentDataContainer;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.java.JavaPlugin;

import java.lang.reflect.Method;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * يشيل دفع الانفجار من باكيت الانفجار للمتفرجين.
 * بدون أي مؤقت شغّال: القائمة تتحدث بالأحداث فقط (تغيّر سلوت الإنفنتوري).
 * فحص نظافة كل 5 ثواني يمر على المتفرجين بس (فاضي غالباً).
 */
public final class SpectatorFix extends JavaPlugin implements Listener {

    private NamespacedKey compassKey;
    private NamespacedKey speedKey;
    private final Set<UUID> spectators = ConcurrentHashMap.newKeySet();
    private PacketListenerAbstract packetListener;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        compassKey = NamespacedKey.fromString(getConfig().getString("compass-key", "practice:fly_spectator_compass"));
        speedKey = NamespacedKey.fromString(getConfig().getString("speed-key", "practice:fly_spectator_speed"));

        Bukkit.getPluginManager().registerEvents(this, this);

        // فحص واحد عند التشغيل (لو انعمل reload والمتفرجين موجودين)
        for (Player p : Bukkit.getOnlinePlayers()) recheck(p);

        // تنظيف نادر: يمر على المتفرجين المسجلين فقط
        Bukkit.getScheduler().runTaskTimer(this, () -> {
            if (spectators.isEmpty()) return;
            for (UUID id : spectators) {
                Player p = Bukkit.getPlayer(id);
                if (p == null || !isFlySpectator(p)) spectators.remove(id);
            }
        }, 100L, 100L);

        packetListener = new PacketListenerAbstract(PacketListenerPriority.NORMAL) {
            @Override
            public void onPacketSend(PacketSendEvent event) {
                if (event.getPacketType() != PacketType.Play.Server.EXPLOSION) return;
                if (spectators.isEmpty()) return;
                UUID id = event.getUser().getUUID();
                if (id == null || !spectators.contains(id)) return;
                WrapperPlayServerExplosion wrapper = new WrapperPlayServerExplosion(event);
                if (zeroKnockback(wrapper)) event.markForReEncode(true);
            }
        };
        PacketEvents.getAPI().getEventManager().registerListener(packetListener);
    }

    @Override
    public void onDisable() {
        if (packetListener != null) {
            try { PacketEvents.getAPI().getEventManager().unregisterListener(packetListener); } catch (Throwable ignored) {}
        }
        spectators.clear();
    }

    private boolean zeroKnockback(WrapperPlayServerExplosion w) {
        Vector3d zero = new Vector3d(0, 0, 0);
        for (String name : new String[]{"setKnockback", "setPlayerMotion"}) {
            try {
                Method m = WrapperPlayServerExplosion.class.getMethod(name, Vector3d.class);
                m.invoke(w, zero);
                return true;
            } catch (NoSuchMethodException ignored) {
            } catch (Throwable t) {
                getLogger().warning("Failed to zero explosion knockback: " + t);
                return false;
            }
        }
        getLogger().warning("No knockback setter found in WrapperPlayServerExplosion — update the plugin for your PacketEvents version.");
        return false;
    }

    private boolean hasMarker(ItemStack it) {
        if (it == null || !it.hasItemMeta()) return false;
        PersistentDataContainer pdc = it.getItemMeta().getPersistentDataContainer();
        return (compassKey != null && pdc.has(compassKey, PersistentDataType.BYTE))
                || (speedKey != null && pdc.has(speedKey, PersistentDataType.BYTE));
    }

    private boolean isFlySpectator(Player p) {
        if (!p.isInvulnerable() || !p.getAllowFlight()) return false;
        for (int i = 0; i < 9; i++) {
            if (hasMarker(p.getInventory().getItem(i))) return true;
        }
        return false;
    }

    private void recheck(Player p) {
        if (isFlySpectator(p)) spectators.add(p.getUniqueId());
        else spectators.remove(p.getUniqueId());
    }

    // ───── أحداث فقط، بدون polling ─────

    @EventHandler
    public void onSlotChange(PlayerInventorySlotChangeEvent e) {
        Player p = e.getPlayer();
        if (hasMarker(e.getNewItemStack())) {
            spectators.add(p.getUniqueId());
        } else if (spectators.contains(p.getUniqueId()) && hasMarker(e.getOldItemStack())) {
            // انشال أيتم المتفرج: نتحقق بعد tick
            Bukkit.getScheduler().runTask(this, () -> { if (p.isOnline()) recheck(p); });
        }
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent e) {
        Bukkit.getScheduler().runTaskLater(this, () -> { if (e.getPlayer().isOnline()) recheck(e.getPlayer()); }, 2L);
    }

    @EventHandler
    public void onWorldChange(PlayerChangedWorldEvent e) {
        Bukkit.getScheduler().runTaskLater(this, () -> { if (e.getPlayer().isOnline()) recheck(e.getPlayer()); }, 2L);
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        spectators.remove(e.getPlayer().getUniqueId());
    }

    @EventHandler(ignoreCancelled = true)
    public void onVelocity(PlayerVelocityEvent e) {
        if (spectators.contains(e.getPlayer().getUniqueId())) e.setCancelled(true);
    }
}
